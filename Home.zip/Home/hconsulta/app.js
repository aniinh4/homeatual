const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const app = express();

// Configuração do banco de dados
const db = mysql.createConnection({
    host: 'localhost',
    user: 'phpmyadmin',
    password: 'aluno',
    database: 'mydb'
});

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Conectado ao banco de dados MySQL');
});

// Configuração do EJS e Body Parser
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Rota para exibir consultas marcadas
app.get('/consultas', (req, res) => {
    const sql = 'SELECT * FROM consultas';
    db.query(sql, (err, result) => {
        if (err) throw err;
        res.render('consultas', { consultas: result });
    });
});

app.set('view engine','ejs');
app.get('/cadastro', (req, res) => {
res.render('cadastro'); //renders vies/cadastro.ejs
app.use(express.static(_dirname + '/'));
});

app.post('/cadastro', (req, res) => {
  const { nome, data, hora } = req.body;
  const query = 'INSERT INTO consultas ( nome, data, hora) VALUES (?, ?, ? )';
  db.query(query, [nome, data, hora] , (err, result) => {
    if (err) {
      console.error('Erro ao cadastrar a consulta:', err);
      res.status(500).send('Erro ao cadastrar o usuário.');
    }
     else {
      console.log('Consulta cadastrada com sucesso!');
      res.status(200).send('Consulta cadastrada com sucesso');
    }
  });
});
// Inicie o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});


